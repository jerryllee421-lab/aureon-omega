from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from ..models import Direction, MarketContext, Regime, SetupCandidate

@dataclass(frozen=True)
class LiquidityMSSConfig:
    pool_lookback:int=12
    atr_period:int=14
    min_displacement_atr:float=0.8
    recent_sweep_bars:int=8


def _atr(df,n):
    prev=df.mid_close.shift(1)
    tr=pd.concat([(df.mid_high-df.mid_low).abs(),(df.mid_high-prev).abs(),(df.mid_low-prev).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False,min_periods=n).mean()

class LiquiditySweepMSS:
    specialist_id="LIQUIDITY_SWEEP_MSS"
    def __init__(self,cfg:LiquidityMSSConfig=LiquidityMSSConfig()):self.cfg=cfg
    def detect(self,ctx:MarketContext)->SetupCandidate|None:
        h=ctx.closed.reset_index(drop=True)
        if len(h)<self.cfg.pool_lookback+5:return None
        atr=_atr(h,self.cfg.atr_period)
        # Search recent sweep then require next bar MSS/displacement.
        for sweep_i in range(len(h)-3,max(self.cfg.pool_lookback,len(h)-self.cfg.recent_sweep_bars)-1,-1):
            pool=h.iloc[sweep_i-self.cfg.pool_lookback:sweep_i]
            lo=float(pool.mid_low.min()); hi=float(pool.mid_high.max())
            sw=h.iloc[sweep_i]; mss=h.iloc[sweep_i+1]
            a=float(atr.iloc[sweep_i+1]) if np.isfinite(atr.iloc[sweep_i+1]) else np.nan
            if not np.isfinite(a) or a<=0: continue
            body=abs(float(mss.mid_close)-float(mss.mid_open))
            bull_sweep=sw.mid_low<lo and sw.mid_close>lo
            bear_sweep=sw.mid_high>hi and sw.mid_close<hi
            if bull_sweep and mss.mid_close>hi and mss.mid_close>mss.mid_open and body>=a*self.cfg.min_displacement_atr:
                direction=Direction.LONG
                zl=float(mss.mid_open); zh=float(mss.mid_open+0.60*(mss.mid_close-mss.mid_open))
            elif bear_sweep and mss.mid_close<lo and mss.mid_close<mss.mid_open and body>=a*self.cfg.min_displacement_atr:
                direction=Direction.SHORT
                zh=float(mss.mid_open); zl=float(mss.mid_open-0.60*(mss.mid_open-mss.mid_close))
            else: continue
            px=ctx.ask_open if direction is Direction.LONG else ctx.bid_open
            # Detection remains valid even before retracement; flag readiness in quality.
            formed=pd.to_datetime(mss.time,utc=True)
            return SetupCandidate(
                specialist_id=self.specialist_id,direction=direction,setup_time=formed,zone_low=min(zl,zh),zone_high=max(zl,zh),
                invalidation=float(sw.mid_low if direction is Direction.LONG else sw.mid_high),trigger=(zl+zh)/2,
                quality={"sweep_reclaim":True,"mss":True,"displacement_atr":body/a,"current_open_in_value":min(zl,zh)<=px<=max(zl,zh)},
                regime=Regime.LIQUIDITY_REVERSAL,data_fidelity=ctx.data_fidelity,
                identity_inputs=(self.specialist_id,int(direction),pd.to_datetime(sw.time,utc=True).isoformat(),round(lo,8),round(hi,8)),
            )
        return None
