from __future__ import annotations

from typing import Protocol

from ..models import MarketContext, SetupCandidate


class Specialist(Protocol):
    specialist_id: str

    def detect(self, ctx: MarketContext) -> SetupCandidate | None: ...
