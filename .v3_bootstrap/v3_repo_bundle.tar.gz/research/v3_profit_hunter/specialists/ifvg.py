from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

from ..models import Direction, MarketContext, Regime, SetupCandidate


@dataclass(frozen=True)
class IFVGConfig:
    atr_period: int = 14
    min_fvg_atr: float = 0.10
    min_body_atr: float = 0.50
    min_body_ratio: float = 0.55
    lookback: int = 40


def _atr(df: pd.DataFrame, n: int) -> pd.Series:
    prev=df.mid_close.shift(1)
    tr=pd.concat([(df.mid_high-df.mid_low).abs(),(df.mid_high-prev).abs(),(df.mid_low-prev).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False,min_periods=n).mean()


class IFVGFlip:
    specialist_id="IFVG_FLIP"
    def __init__(self,cfg:IFVGConfig=IFVGConfig()): self.cfg=cfg

    def detect(self,ctx:MarketContext)->SetupCandidate|None:
        h=ctx.closed
        if len(h)<self.cfg.atr_period+6: return None
        atr=_atr(h,self.cfg.atr_period).to_numpy(float)
        start=max(2,len(h)-self.cfg.lookback)
        candidates=[]
        for new_i in range(start,len(h)-2):
            old_i,mid_i=new_i-2,new_i-1
            a=atr[new_i]
            if not np.isfinite(a) or a<=0: continue
            old,mid,new=h.iloc[old_i],h.iloc[mid_i],h.iloc[new_i]
            body=abs(mid.mid_close-mid.mid_open); rng=mid.mid_high-mid.mid_low
            if rng<=0 or body<a*self.cfg.min_body_atr or body/rng<self.cfg.min_body_ratio: continue
            original=None; zl=zh=0.0
            if old.mid_high<new.mid_low and mid.mid_close>mid.mid_open and new.mid_low-old.mid_high>=a*self.cfg.min_fvg_atr:
                original=Direction.LONG; zl=float(old.mid_high); zh=float(new.mid_low)
            elif old.mid_low>new.mid_high and mid.mid_close<mid.mid_open and old.mid_low-new.mid_high>=a*self.cfg.min_fvg_atr:
                original=Direction.SHORT; zl=float(new.mid_high); zh=float(old.mid_low)
            if original is None: continue
            later=h.iloc[new_i+1:]
            if len(later)<2: continue
            flip_idx=None; retest_idx=None; direction=None
            if original is Direction.SHORT:
                hits=np.where(later.mid_close.to_numpy()>zh)[0]
                if len(hits):
                    flip_idx=new_i+1+int(hits[0]); direction=Direction.LONG
                    after=h.iloc[flip_idx+1:]
                    for j,row in after.iterrows():
                        if row.mid_low<=zh and row.mid_close>=zl:
                            retest_idx=j; break
            else:
                hits=np.where(later.mid_close.to_numpy()<zl)[0]
                if len(hits):
                    flip_idx=new_i+1+int(hits[0]); direction=Direction.SHORT
                    after=h.iloc[flip_idx+1:]
                    for j,row in after.iterrows():
                        if row.mid_high>=zl and row.mid_close<=zh:
                            retest_idx=j; break
            if retest_idx is None: continue
            formed=pd.to_datetime(h.iloc[retest_idx].time,utc=True)
            candidates.append((retest_idx,SetupCandidate(
                specialist_id=self.specialist_id,direction=direction,setup_time=formed,
                zone_low=zl,zone_high=zh,invalidation=zl if direction is Direction.LONG else zh,
                trigger=(zl+zh)/2,regime=Regime.UNKNOWN_DEGRADED,data_fidelity=ctx.data_fidelity,
                quality={"original_fvg_direction":"LONG" if original is Direction.LONG else "SHORT","flip_confirmed":True,"retest_confirmed":True},
                identity_inputs=(self.specialist_id,int(direction),formed.isoformat(),round(zl,8),round(zh,8)),
            )))
        return max(candidates,key=lambda z:z[0])[1] if candidates else None
