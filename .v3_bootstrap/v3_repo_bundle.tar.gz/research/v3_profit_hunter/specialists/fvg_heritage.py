from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from ..models import Direction, MarketContext, Regime, SetupCandidate


@dataclass(frozen=True)
class FVGHeritageConfig:
    min_fvg_atr: float = 0.15
    min_body_atr: float = 0.50
    min_body_ratio: float = 0.60
    max_fvg_bars: int = 1000
    atr_period: int = 14
    require_rejection: bool = True


def _atr(df: pd.DataFrame, n: int) -> pd.Series:
    prev = df["mid_close"].shift(1)
    tr = pd.concat([
        (df["mid_high"]-df["mid_low"]).abs(),
        (df["mid_high"]-prev).abs(),
        (df["mid_low"]-prev).abs(),
    ], axis=1).max(axis=1)
    return tr.ewm(alpha=1.0/n, adjust=False, min_periods=n).mean()


class V217FVGHeritage:
    specialist_id = "V217_FVG_HERITAGE"

    def __init__(self, cfg: FVGHeritageConfig = FVGHeritageConfig()):
        self.cfg = cfg

    def detect(self, ctx: MarketContext) -> SetupCandidate | None:
        h = ctx.closed
        if len(h) < self.cfg.atr_period + 3:
            return None
        atr = _atr(h, self.cfg.atr_period).to_numpy(dtype=float)
        n = len(h)
        min_new = max(2, n - self.cfg.max_fvg_bars)
        for new_i in range(n-1, min_new-1, -1):
            mid_i, old_i = new_i-1, new_i-2
            a = atr[new_i]
            if not np.isfinite(a) or a <= 0:
                continue
            old = h.iloc[old_i]; mid = h.iloc[mid_i]; new = h.iloc[new_i]
            body = abs(float(mid.mid_close)-float(mid.mid_open))
            rng = float(mid.mid_high)-float(mid.mid_low)
            if body < a*self.cfg.min_body_atr or rng <= 0 or body/rng < self.cfg.min_body_ratio:
                continue

            direction: Direction | None = None
            zone_low = zone_high = 0.0
            gap = 0.0
            if float(old.mid_high) < float(new.mid_low) and float(mid.mid_close) > float(mid.mid_open):
                gap = float(new.mid_low)-float(old.mid_high)
                if gap >= a*self.cfg.min_fvg_atr:
                    direction = Direction.LONG
                    zone_low, zone_high = float(old.mid_high), float(new.mid_low)
            elif float(old.mid_low) > float(new.mid_high) and float(mid.mid_close) < float(mid.mid_open):
                gap = float(old.mid_low)-float(new.mid_high)
                if gap >= a*self.cfg.min_fvg_atr:
                    direction = Direction.SHORT
                    zone_low, zone_high = float(new.mid_high), float(old.mid_low)
            if direction is None:
                continue

            later_close = h.iloc[new_i+1:]["mid_close"]
            if direction is Direction.LONG and (later_close < zone_low).any():
                continue
            if direction is Direction.SHORT and (later_close > zone_high).any():
                continue

            formed = pd.to_datetime(new["time"], utc=True)
            px = ctx.ask_open if direction is Direction.LONG else ctx.bid_open
            identity = (
                self.specialist_id,
                int(direction),
                formed.isoformat(),
                round(zone_low, 8),
                round(zone_high, 8),
            )
            return SetupCandidate(
                specialist_id=self.specialist_id,
                direction=direction,
                setup_time=formed,
                zone_low=zone_low,
                zone_high=zone_high,
                invalidation=zone_low if direction is Direction.LONG else zone_high,
                trigger=(zone_low+zone_high)/2.0,
                quality={
                    "gap_atr": gap/a,
                    "displacement_atr": body/a,
                    "body_ratio": body/rng,
                    "zone_age_bars": n-1-new_i,
                    "requires_rejection": self.cfg.require_rejection,
                    "current_open_in_zone": zone_low <= px <= zone_high,
                },
                regime=Regime.UNKNOWN_DEGRADED,
                data_fidelity=ctx.data_fidelity,
                identity_inputs=identity,
            )
        return None
