from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from ..features import FeatureConfig, prepare_features
from ..models import Direction, MarketContext, Regime, SetupCandidate

@dataclass(frozen=True)
class TrendPullbackConfig:
    lookback:int=8
    max_pullback_atr:float=1.5

class TrendPullback:
    specialist_id="TREND_PULLBACK"
    def __init__(self,cfg:TrendPullbackConfig=TrendPullbackConfig()):self.cfg=cfg
    def detect(self,ctx:MarketContext)->SetupCandidate|None:
        # Append a placeholder current bar; all prepared features are shifted and therefore use closed history only.
        h=ctx.closed.copy(); last=h.iloc[-1].copy(); last["time"]=ctx.decision_time
        for side in ("bid","ask","mid"):
            p=ctx.bid_open if side=="bid" else ctx.ask_open if side=="ask" else (ctx.bid_open+ctx.ask_open)/2
            for k in ("open","high","low","close"): last[f"{side}_{k}"]=p
        last["spread_open"]=ctx.spread_open; last["spread_close"]=ctx.spread_open
        z=pd.concat([h,pd.DataFrame([last])],ignore_index=True)
        f=prepare_features(z,FeatureConfig(percentile_window=60)); row=f.iloc[-1]
        req=[row.get(k,np.nan) for k in ("atr","ema20","ema50","ema100","ema200")]
        if not all(np.isfinite(v) for v in req):return None
        atr,e20,e50,e100,e200=map(float,req)
        latest=h.iloc[-1]; recent=h.iloc[-self.cfg.lookback:]
        if e20>e50>e100>e200:
            touched=float(recent.mid_low.min())<=e20+0.35*atr
            resume=latest.mid_close>latest.mid_open and latest.mid_close>=e20
            if not (touched and resume):return None
            direction=Direction.LONG; zl=float(recent.mid_low.min()); zh=float(latest.mid_close); invalid=float(recent.mid_low.min())
        elif e20<e50<e100<e200:
            touched=float(recent.mid_high.max())>=e20-0.35*atr
            resume=latest.mid_close<latest.mid_open and latest.mid_close<=e20
            if not (touched and resume):return None
            direction=Direction.SHORT; zl=float(latest.mid_close); zh=float(recent.mid_high.max()); invalid=float(recent.mid_high.max())
        else:return None
        formed=pd.to_datetime(latest.time,utc=True)
        return SetupCandidate(self.specialist_id,direction,formed,min(zl,zh),max(zl,zh),invalid,(zl+zh)/2,
            {"trend_aligned":True,"ema20":e20,"ema50":e50,"atr":atr},Regime.TREND_PULLBACK,ctx.data_fidelity,
            (self.specialist_id,int(direction),formed.isoformat(),round(e20,8),round(e50,8)))
