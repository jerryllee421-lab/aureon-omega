from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from ..models import Direction, MarketContext, Regime, SetupCandidate

@dataclass(frozen=True)
class MomentumConfig:
    atr_period:int=14
    compression_bars:int=10
    max_compression_ratio:float=0.65
    min_expansion_atr:float=1.0
    min_body_efficiency:float=0.70


def _atr(df,n):
    prev=df.mid_close.shift(1)
    tr=pd.concat([(df.mid_high-df.mid_low).abs(),(df.mid_high-prev).abs(),(df.mid_low-prev).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False,min_periods=n).mean()

class MomentumExpansion:
    specialist_id="MOMENTUM_EXPANSION"
    def __init__(self,cfg:MomentumConfig=MomentumConfig()):self.cfg=cfg
    def detect(self,ctx:MarketContext)->SetupCandidate|None:
        h=ctx.closed.reset_index(drop=True); atr=_atr(h,self.cfg.atr_period)
        if len(h)<self.cfg.atr_period+self.cfg.compression_bars+3:return None
        for i in range(len(h)-1,max(self.cfg.compression_bars,len(h)-4)-1,-1):
            a=float(atr.iloc[i]) if np.isfinite(atr.iloc[i]) else np.nan
            if not np.isfinite(a) or a<=0:continue
            b=h.iloc[i]; body=abs(float(b.mid_close)-float(b.mid_open)); rng=float(b.mid_high-b.mid_low)
            if rng<=0 or body<a*self.cfg.min_expansion_atr or body/rng<self.cfg.min_body_efficiency:continue
            prior=h.iloc[i-self.cfg.compression_bars:i]
            cr=float((prior.mid_high-prior.mid_low).median()/a)
            if cr>self.cfg.max_compression_ratio:continue
            direction=Direction.LONG if b.mid_close>b.mid_open else Direction.SHORT
            formed=pd.to_datetime(b.time,utc=True)
            zl=float(min(b.mid_open,b.mid_close)); zh=float(max(b.mid_open,b.mid_close))
            return SetupCandidate(self.specialist_id,direction,formed,zl,zh,
                float(b.mid_low if direction is Direction.LONG else b.mid_high),float(b.mid_close),
                {"compression_ratio":cr,"expansion_atr":body/a,"body_efficiency":body/rng},Regime.VOLATILITY_EXPANSION,
                ctx.data_fidelity,(self.specialist_id,int(direction),formed.isoformat(),round(zl,8),round(zh,8)))
        return None
