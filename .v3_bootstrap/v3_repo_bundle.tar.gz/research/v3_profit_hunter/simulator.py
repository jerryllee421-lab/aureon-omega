from __future__ import annotations

from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd

from .data_contract import decision_view
from .entry import make_event_id
from .excursions import profit_capture_ratio
from .models import Direction


@dataclass(frozen=True)
class TradeRecord:
    specialist_id: str
    event_id: str
    direction: int
    entry_i: int
    exit_i: int
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp
    entry: float
    stop: float
    target: float
    exit: float
    risk: float
    r: float
    net_r: float
    reason: str
    mfe_r: float
    mae_r: float
    pcr: float | None
    session: str = "UNKNOWN"
    regime: str = "UNKNOWN"


@dataclass(frozen=True)
class SimulationPolicy:
    reward_risk: float = 2.0
    max_hold_bars: int = 30
    cost_r: float = 0.0
    max_history_bars: int = 300


@dataclass(frozen=True)
class SimulationResult:
    trades: pd.DataFrame
    metrics: object


def simulate_single_trade(
    df: pd.DataFrame,
    entry_i: int,
    direction: Direction,
    *,
    entry: float,
    stop: float,
    target: float,
    max_hold_bars: int,
    cost_r: float = 0.0,
    specialist_id: str = "TEST",
    event_id: str = "TEST",
    session: str = "UNKNOWN",
    regime: str = "UNKNOWN",
) -> TradeRecord:
    risk = (entry-stop) if direction is Direction.LONG else (stop-entry)
    if risk <= 0:
        raise ValueError("stop must define positive directional risk")
    last = min(len(df)-1, entry_i + max(1, int(max_hold_bars)))
    exit_i = last
    exit_px = None
    reason = "TIME"
    mfe_r = 0.0
    mae_r = 0.0

    for i in range(entry_i+1, last+1):
        row = df.iloc[i]
        if direction is Direction.LONG:
            favorable = float(row.bid_high)-entry
            adverse = entry-float(row.bid_low)
            stop_hit = float(row.bid_low) <= stop
            tp_hit = float(row.bid_high) >= target
        else:
            favorable = entry-float(row.ask_low)
            adverse = float(row.ask_high)-entry
            stop_hit = float(row.ask_high) >= stop
            tp_hit = float(row.ask_low) <= target
        mfe_r = max(mfe_r, max(0.0, favorable/risk))
        mae_r = max(mae_r, max(0.0, adverse/risk))
        # Conservative bar proxy: if both are touched and tick order is unknown, stop wins.
        if stop_hit:
            exit_px = stop; exit_i = i; reason = "SL"; break
        if tp_hit:
            exit_px = target; exit_i = i; reason = "TP"; break

    if exit_px is None:
        row = df.iloc[exit_i]
        exit_px = float(row.bid_close if direction is Direction.LONG else row.ask_close)

    r = ((exit_px-entry)/risk) if direction is Direction.LONG else ((entry-exit_px)/risk)
    net_r = r - float(cost_r)
    realized_favorable = max(0.0, r)
    pcr = profit_capture_ratio(realized_favorable, mfe_r)
    return TradeRecord(
        specialist_id=specialist_id,event_id=event_id,direction=int(direction),entry_i=entry_i,exit_i=exit_i,
        entry_time=pd.to_datetime(df.iloc[entry_i].time,utc=True),exit_time=pd.to_datetime(df.iloc[exit_i].time,utc=True),
        entry=float(entry),stop=float(stop),target=float(target),exit=float(exit_px),risk=float(risk),
        r=float(r),net_r=float(net_r),reason=reason,mfe_r=float(mfe_r),mae_r=float(mae_r),pcr=pcr,
        session=session,regime=regime,
    )


def simulate(frame: pd.DataFrame, specialists: list, policy: SimulationPolicy, execution_model: str = "BID_ASK_M1_BAR_PROXY") -> SimulationResult:
    if execution_model != "BID_ASK_M1_BAR_PROXY":
        raise ValueError("research simulator supports BID_ASK_M1_BAR_PROXY only")
    records: list[TradeRecord] = []
    i = max(20, min(policy.max_history_bars, len(frame)-1))
    while i < len(frame)-1:
        start = max(0, i-policy.max_history_bars)
        local = frame.iloc[start:i+1].reset_index(drop=True)
        try:
            ctx = decision_view(local, len(local)-1)
        except ValueError:
            i += 1; continue
        candidate = None
        for specialist in specialists:
            candidate = specialist.detect(ctx)
            if candidate is not None:
                break
        if candidate is None:
            i += 1; continue
        entry = ctx.ask_open if candidate.direction is Direction.LONG else ctx.bid_open
        stop = float(candidate.invalidation)
        risk = (entry-stop) if candidate.direction is Direction.LONG else (stop-entry)
        if risk <= 0:
            i += 1; continue
        target = entry + int(candidate.direction)*risk*policy.reward_risk
        record = simulate_single_trade(
            frame,i,candidate.direction,entry=entry,stop=stop,target=target,max_hold_bars=policy.max_hold_bars,
            cost_r=policy.cost_r,specialist_id=candidate.specialist_id,event_id=make_event_id(candidate),
            session=str(candidate.quality.get("session","UNKNOWN")),regime=candidate.regime.value,
        )
        records.append(record)
        i = max(i+1, record.exit_i+1)
    trades = pd.DataFrame([asdict(r) for r in records])
    from .metrics import summarize
    return SimulationResult(trades=trades,metrics=summarize(trades))
